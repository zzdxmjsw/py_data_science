fiona package
=============

Subpackages
-----------

.. toctree::

    fiona.fio

Submodules
----------

fiona.collection module
-----------------------

.. automodule:: fiona.collection
    :members:
    :undoc-members:
    :show-inheritance:

fiona.compat module
-------------------

.. automodule:: fiona.compat
    :members:
    :undoc-members:
    :show-inheritance:

fiona.crs module
----------------

.. automodule:: fiona.crs
    :members:
    :undoc-members:
    :show-inheritance:

fiona.drvsupport module
-----------------------

.. automodule:: fiona.drvsupport
    :members:
    :undoc-members:
    :show-inheritance:

fiona.errors module
-------------------

.. automodule:: fiona.errors
    :members:
    :undoc-members:
    :show-inheritance:

fiona.inspector module
----------------------

.. automodule:: fiona.inspector
    :members:
    :undoc-members:
    :show-inheritance:

fiona.ogrext module
-------------------

.. automodule:: fiona.ogrext
    :members:
    :undoc-members:
    :show-inheritance:

fiona.ogrext1 module
--------------------

.. automodule:: fiona.ogrext1
    :members:
    :undoc-members:
    :show-inheritance:

fiona.ogrext2 module
--------------------

.. automodule:: fiona.ogrext2
    :members:
    :undoc-members:
    :show-inheritance:

fiona.rfc3339 module
--------------------

.. automodule:: fiona.rfc3339
    :members:
    :undoc-members:
    :show-inheritance:

fiona.tool module
-----------------

.. automodule:: fiona.tool
    :members:
    :undoc-members:
    :show-inheritance:

fiona.transform module
----------------------

.. automodule:: fiona.transform
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: fiona
    :members:
    :undoc-members:
    :show-inheritance:
