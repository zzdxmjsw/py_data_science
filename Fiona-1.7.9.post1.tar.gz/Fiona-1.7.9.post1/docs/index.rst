Fiona Documentation Contents
============================

.. toctree::
   :maxdepth: 2

   README
   User Manual <manual>
   API Documentation <modules>
   CLI Documentation <cli>


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

